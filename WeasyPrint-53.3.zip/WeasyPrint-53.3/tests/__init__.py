"""
    weasyprint.tests
    ----------------

    The Weasyprint test suite.

"""
